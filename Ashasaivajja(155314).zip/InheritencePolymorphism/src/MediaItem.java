
abstract class MediaItem {
	private int runTime;

	class Video extends MediaItem {
		private String directior;
		private String genre;
		private int year;
	}
}

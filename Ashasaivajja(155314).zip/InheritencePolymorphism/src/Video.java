
public class Video extends MediaItem {
	private String artist;
	private String genre;
	private int yearOfRealeased;

}

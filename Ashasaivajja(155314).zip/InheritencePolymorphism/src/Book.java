
public class Book extends WrittenItem {

	public Book(int idNum, String str, int n, String author2, int y) {
		super(idNum, str, n, author2, y);
		// TODO Auto-generated constructor stub
	}

}

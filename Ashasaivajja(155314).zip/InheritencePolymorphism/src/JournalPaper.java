
public class JournalPaper extends WrittenItem {
	private int yearOfPublished;

	public JournalPaper(int idNum, String str, int n, String author2, int y) {
		super(idNum, str, n, author2, y);
		// TODO Auto-generated constructor stub
	}

}


public interface LibraryUser {

	void registerAccount(int age);

	void requestBook(String bookType);

}

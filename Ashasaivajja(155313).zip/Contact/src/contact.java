
import java.util.*; 
import java.util.Scanner; 
import java.util.Map.Entry; 
public class contact {
	public static void main(String args[]) {  
   
 HashMap<Long,String> List=new HashMap<Long,String>();
  
  
      List.put(100000000L,"Amit");    
      List.put(1000000001L,"Vijay");    
      List.put(10000000002L,"Rahul");  
      List.put(1030000000L, "Gaurav");  
  
      //Add Contact
      
      Scanner sc = new Scanner(System.in);
      System.out.println("How many contacts you want to add:");
      int num=sc.nextInt();
      
      for(int i=0; i<num;i++)
      {
    	  System.out.println("Enter the name:");
    	  String str=sc.next();
    	  System.out.println("Enter the phone number:");
    	  Long ph=sc.nextLong();
    	  
    	  List.put(ph,str);
      }
      
      //Display Contact
      
      for(Entry<Long, String> entry : List.entrySet()) {
      
    	  String phone = entry.getKey().toString();
          String name = entry.getValue();
          System.out.println("PhoneNumber : " + phone + "  " + " Name:  " + name);
      
}
      //Delete Contact
      
      System.out.println("Which Phone number to delete:");
  	long del = sc.nextLong();
  	List.remove(del);   
  	
  	for(Entry<Long, String> entry : List.entrySet()) {
        
  	  String phone = entry.getKey().toString();
        String name = entry.getValue();
        System.out.println("PhoneNumber : " + phone + "  " + " Name:  " + name);
    
}
  	//No.of contacts
  	
  	 System.out.println("Number of Contacts in list : " + List.size());      
   	
	}
}